<?php
define('my-site',true);
if(!defined('my-site')){

    header("Location: index.php");
    }

?>

<?php 

session_start();

session_unset();
session_destroy();


header("Location: index.php");
?>