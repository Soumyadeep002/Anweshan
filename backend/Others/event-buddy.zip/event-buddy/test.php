<?php
session_start();

$_SESSION['hi'.'40']= "Hello World";

echo $_SESSION['hi'.'40'];


?>