<?php include "db_conn.php";?>

<?php

// if(!defined('my-site')){

//     Header("location:access-denied.html");
//     }


?>


<?php 
         if(isset($_GET['event_id'])){
            $event_id = $_GET['event_id'];
            

           $stmt = "SELECT * FROM admins WHERE event_id='$event_id'";
           $result = $conn->query($stmt);

            if ($result->num_rows > 0)
            {
               $row = $result->fetch_assoc();
               $event_broc = "pdf/{$row['event_broc']}";
               $c_image1 = "image/{$row['c_image1']}";
               $c_image2 = "image/{$row['c_image2']}";
               $c_image3 = "image/{$row['c_image3']}";

             
               ?>
              
               <?php


               $sql = "DELETE FROM admins WHERE event_id='$event_id'";
               $ex = $conn->query($sql);

              
               $sql2 = "DELETE FROM participants WHERE event_id='$event_id'";
               $ex2 = mysqli_query($conn,$sql2);
            
           
               if ($ex && $ex2) 
               {

                  $s1= unlink($event_broc);
                  $s2= unlink($c_image1);
                  $s3= unlink($c_image2);
                  $s4= unlink($c_image3);

                  if( $s1 && $s2 && $s3 && $s4 ){

                  
         
                     ?><script>
                        alert("Event Deleted");
                        window.location.href = "logout.php";
                     </script><?php

                  }else{

                  ?><script>
                     alert("Error in Deleting Event files");
                     window.location.href = "logout.php";
                  </script><?php

                  }
      
               }else{
                  ?> 
                  <script>alert("Error in Deleting Event ")
                  window.location.href = "logout.php";
                  </script>
                  <?php
               }

            }else{
               ?> 
               <script>alert("Event Not Found ")
               window.location.href = "logout.php";
               </script>
               <?php
            }

         }else{
            Header("location:access-denied.html");
           
           
           
         }
            ?>