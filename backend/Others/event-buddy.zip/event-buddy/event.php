<?php


//Starting Session
session_start();

//connecting to data base
include "db_conn.php";
?>

<!DOCTYPE html>
<html lang="en">
<?php


if (isset($_GET['event_id'])) {

    //Storing event id(get method) in variable  
    $event_id = $_GET['event_id'];

    // $events_id =$_POST['events_id'];


    //Query
    $sql = "SELECT event_id,event_name, organizer, event_sdate, event_stime, event_edate, event_etime, event_venue, event_desc, event_broc, c_image1, c_image2, c_image3  FROM admins WHERE event_id='{$event_id}'";

    //Executing Query and storing result in variable
    $result = $conn->query($sql);


    //Checking whether the number of result row is greater than  1 or not 
    if ($result->num_rows > 0) {

        // output data of each row
        while ($row = $result->fetch_assoc()) {
            $event_name = $row['event_name'];

?>

            <head>
                <meta charset="utf-8">
                <meta name="viewport" content="width=device-width, initial-scale=1">
                <title><?php echo $row['event_name']; ?></title>

                <link rel="icon" type="image/x-icon" href="./assets/logo/eb-transperent-logo.png" />

                <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">

                <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>

                <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">

                <link rel="stylesheet" href="css/event.css">

            </head>

            <body>

                <!-- navbar  -->
                <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
                    <div class="container-fluid">
                        <a href="index.php" class="navbar-brand"><img style="height:40px; width: 40px;" src="assets/logo/eb-white-bg-logo.png" alt=""> Event Buddy</a>
                        <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarCollapse">
                            <div class="navbar-nav">
                                <a href="index.php" class="nav-item nav-link active">Home</a>
                                <a href="index.php#events-section" class="nav-item active nav-link">Events</a>
                            </div>
                            <div class="navbar-nav ms-auto">
                                <a href="admin.php" class="nav-item active nav-link"><strong>Admin</strong></a>
                            </div>
                        </div>
                    </div>
                </nav>

                <div class="container">
                    <!-- home-heading  -->
                    <div class="p-5 home-heading">
                        <div class="home-heading-content">
                            <div class="container-lg my-3">

                                <!-- Printing event name and organizer name  -->
                                <h1><?php echo $row['event_name']; ?></h1>

                                <p class="lead"><?php echo $row['organizer']; ?></p>
                                <div id="myCarousel" class="carousel slide" data-bs-ride="carousel">

                                    <!-- Carousel indicators -->
                                    <ol class="carousel-indicators">
                                        <li data-bs-target="#myCarousel" data-bs-slide-to="0" class="active"></li>
                                        <li data-bs-target="#myCarousel" data-bs-slide-to="1"></li>
                                        <li data-bs-target="#myCarousel" data-bs-slide-to="2"></li>
                                    </ol>

                                    <!-- Wrapper for carousel items -->
                                    <div class="carousel-inner">
                                        <div class="carousel-item active">
                                            <img src="image/<?php echo $row['c_image1']; ?>" class="d-block w-100" alt="Slide 1">
                                        </div>
                                        <div class="carousel-item">
                                            <img src="image/<?php echo $row['c_image2']; ?>" class="d-block w-100" alt="Slide 2">
                                        </div>
                                        <div class="carousel-item">
                                            <img src="image/<?php echo $row['c_image3']; ?>" class="d-block w-100" alt="Slide 3">
                                        </div>
                                    </div>

                                    <!-- Carousel controls -->
                                    <a class="carousel-control-prev" href="#myCarousel" data-bs-slide="prev">
                                        <span class="carousel-control-prev-icon"></span>
                                    </a>
                                    <a class="carousel-control-next" href="#myCarousel" data-bs-slide="next">
                                        <span class="carousel-control-next-icon"></span>
                                    </a>
                                </div>
                            </div>

                            <p class="card-date-time">
                                <b>Start Date & time :</b>
                                [<?php echo $row['event_sdate']; ?>] [<?php echo $row['event_stime']; ?>]
                            </p>

                            <p class="card-date-time">
                                <b>End Date & time :</b>
                                [<?php echo $row['event_edate']; ?>] [<?php echo $row['event_etime']; ?>]
                            </p>

                            <p class="card-Venue">
                                <b>Venue :</b>
                                <?php echo $row['event_venue']; ?>
                            </p>

                            <p class="card-event-description-title">
                                <b>Event Description :</b>
                            </p>

                            <p class="card-event-description">
                                <?php echo $row['event_desc']; ?>
                            </p>


                            <a target="_blank" href="pdf/<?php echo $row['event_broc']; ?>" type="button" class="btn btn-primary">Event Brochure</a>
                            <!-- <a type="display" class="btn btn-success" target="_blank" href="QR/Generation/display-qr.php?event_id=<?php echo $event_id; ?>">Show QR Code</a> -->

                            <!-- <a type="display" class="btn btn-success" target="_blank" href="QR/Generation/display-qr.php?event_id=<?php echo $event_id ?>&p_email=<?php echo $p_email ?>">Show QR Code</a> -->


                            <!-- event-registration-form  -->
                            <form action="event.php?event_id=<?php echo $event_id ?>" method="POST">
                                <div class="modal-header">
                                    <h5 class="modal-title">Register for the Event</h5>

                                </div>
                                <div class="modal-body">
                                    <div class="mb-3">
                                        <label class="form-label">Name</label>
                                        <input type="text" id="p_name" class="form-control form_data" name="p_name">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Email:</label>
                                        <input type="email" id="p_email" class="form-control form_data" name="p_email">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Mobile Number:</label>
                                        <input type="text" id="mobile" class="form-control form_data" name="mobile">
                                    </div>



                                </div>
                                <div class="modal-footer">
                                    <a href="index.php" class="btn btn-warning">Cancel</a>
                                    <button type="submit" id="submit" name="submit" class="btn btn-success">Register</button>
                                </div>
                            </form>

                            <!-- event-registration.php -->
                            <?php
                            function test_input($data)
                            {
                                $data = trim($data);
                                $data = stripslashes($data);
                                $data = htmlspecialchars($data);
                                return $data;
                            }

                            if (isset($_POST['submit'])) {
                                if (!empty($_POST['p_name']) && !empty($_POST['p_email']) && !empty('mobile')) {
                                    $p_name = test_input($_POST['p_name']);
                                    $p_email = test_input($_POST['p_email']);
                                    $mobile = test_input($_POST['mobile']);

                                    //Executing query to get details of relevant participants
                                    $sql = "SELECT * FROM participants WHERE event_id ='$event_id' AND p_email='$p_email'";
                                    $result = $conn->query($sql);

                                    if ($result->num_rows > 0) {
                            ?>
                                        <script>
                                            alert("Already Registered");
                                            window.location.href = "event.php?event_id=<?php echo $event_id ?>";
                                        </script>
                                        <?php
                                    } else {






                                        //QR Generation
                                        require_once 'QR/Generation/phpqrcode/qrlib.php';
                                        $path = 'QR/Generation/images/';
                                        $qrcode = $path . time() . ".png";
                                        $qrimage = time() . ".png";


                                        $key = "eventbuddy";

                                        //Encrypting
                                        function encryption($data, $key)
                                        {
                                            $encryption_key = base64_decode($key);
                                            $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length('aes-256-cbc'));
                                            $encrypted = openssl_encrypt($data, 'aes-256-cbc', $encryption_key, 0, $iv);
                                            return base64_encode($encrypted . '::' . $iv);
                                        }

                                        $en_event_id = encryption($event_id, $key);
                                        $en_p_mail = encryption($p_email, $key);

                                        QRcode::png("{$en_event_id}:{$en_p_mail}", $qrcode, 'H', 4, 4);




                                        $stmt = $conn->prepare("INSERT INTO participants (p_email, event_id, p_name, mobile, qr_image) VALUES(?, ?, ?, ?,?)");
                                        $stmt->bind_param("sssss", $p_email, $event_id, $p_name, $mobile, $qrimage);
                                        $stmt->execute();
                                        $stmt->close();
                                        if ($stmt) {
                                            $_SESSION['e_p_email'] = $p_email;
                                            $_SESSION['e_event_name'] = $event_name;
                                            $_SESSION['e_event_id'] = $event_id;
                                            $_SESSION['e_p_name'] = $p_name;
                                            $_SESSION['e_qrimage'] = $qrimage;
                                        ?>
                                            <script>
                                                alert("Registered for the event. Check your mail for the QR-ticket.");
                                                window.location.href = "Mail/send-p-mail.php";
                                            </script>
                                        <?php
                                        } else {
                                        ?>
                                            <script>
                                                alert("Error try again");
                                                window.location.href = "event.php?event_id=<?php echo $event_id ?>";
                                            </script>
                                    <?php
                                        }
                                    }
                                } else {
                                    ?>
                                    <script>
                                        alert("Submitted minimum one empty form data");
                                        window.location.href = "event.php?event_id=<?php echo $event_id ?>";
                                    </script>
                                <?php


                                }
                            } else {

                                ?>
                                <!-- <script>
                                        alert("Error in Form Submission");
                                        window.location.href = "event.php?event_id=<?php echo $event_id ?>";
                                        </script> -->
                            <?php

                            }
                            ?>

                        </div>

                    </div>

                    <!-- footer  -->
                    <footer>
                        <div class="footer-content">
                            <a href="https://github.com/rdtech2002/event-buddy-university-project-01" target="_blank"><i class="bi bi-github"></i></a>
                            <p>Copyright © 2022 Event Buddy</p>
                        </div>
                    </footer>
                </div>

            </body>

</html>




<?php


        }
    } else {
?>
<script>
    alert("No Such Event");
    window.location.href = "index.php";
</script>
<?php
    }
} else {
?>
<script>
    window.location.href = "access-denied.html";
</script>
<?php
}
?>