<?php

if(!defined('my-site')){

    Header("location:../access-denied.html");
    }
    
?>