
<head>
<title>Sending Mail</title>
<!-- logo -->
<link rel="icon" type="image/x-icon" href="../assets/logo/eb-transperent-logo.png" />

</head>

<?php

include "db.php";
session_start();
//Import PHPMailer classes into the global namespace
//These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

if (isset($_SESSION['e_event_id']) &&  isset($_SESSION['e_p_email'])) {

    $p_name = $_SESSION['e_p_name'];
    $event_name = $_SESSION['e_event_name'];
    $event_id = $_SESSION['e_event_id'];
    $p_email = $_SESSION['e_p_email'];
    $qrimage = $_SESSION['e_qrimage'];

    require 'PHPMailer/src/Exception.php';
    require 'PHPMailer/src/PHPMailer.php';
    require 'PHPMailer/src/SMTP.php';

    $mail = new PHPMailer(true);

    try {
        //Server settings
        // $mail ->isSMTP();              
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
        $mail->Username   = 'eventbuddy05@gmail.com';  // ! admin.eventbuddy@gmail.com
        $mail->Password   = 'wobegropabtylszh';                               //SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
        $mail->Port       = 465;
        // $mail->IsHTML(true);                                  //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

        //Recipients
        $mail->setFrom('eventbuddy05@gmail.com', "admin@Event-Buddy");
        $mail->addAddress($p_email, $p_name);     //Add a recipient

        //Attachments
        $path = "../QR/Generation/images/$qrimage";
        // $mail->addAttachment($path);         //Add attachments
        $mail->AddEmbeddedImage($path, 'banana');

        //Content
        $mail->isHTML(true);                                  //Set email format to HTML 
        $mail->Subject = 'Hey ' . $p_name . ' here is your ticket for ' . $event_name;
        //body of the mail





        // ob_start();
        // include('test.php');

        $mail->Body   =
            '
        <div style="text-align: center;border: 2px solid gray; width: fit-content; margin: auto; border-radius: 18px; background-color: rgb(193, 240, 252); padding: 10px;">
                <div style="border-bottom: 2px solid gray; border-radius: 10px;">
                    <img style="margin-left: 20px;" width="100px" height="50px"
                        src="https://github.com/irahuldutta02/dynamic-images/blob/main/event-buddy-files/logo/eb-transperent-logo-16-9.png?raw=true"
                        alt="event-buddy">
                </div>
                <div style="text-align: center; display: flex; padding: 10px; justify-content: center;">
                    <div style="margin: 10px; margin-left: 0px;">
                        <img height="250px" width="250px" src="cid:banana" alt="event-qr">
                    </div>
                </div>
                <div style="border-top: 2px solid gray; border-radius: 10px; ">
                    <p><b style="color: rgb(0, 184, 0);" >Your booking is confirmed.</b></p>
                    <p><b>Show this QR Ticket at entry</b></p>
                </div>
            </div>
        ';



        // ob_get_contents();

        // ob_end_clean();


























        $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
        $mail->send();
?>
<script>
    window.location.href = "../event.php?event_id=<?php echo $event_id ?>";
</script>
<?php
        // session_unset();
        // session_destroy();
        
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
} else {
    ?>
<script>
    alert("Mail not sent");
    window.location.href = "../event.php?event_id=<?php echo $event_id ?>";
</script>
<?php
}