<?php

session_start();

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

if (isset($_SESSION['event_id'])) {

include "../db_conn.php";


$event_id =$_SESSION['event_id'];

$sql = "SELECT * FROM participants WHERE event_id ='$event_id' AND flag=1";
$result = $conn->query($sql);


$sql2 = "SELECT * FROM admins WHERE event_id ='$event_id'";
$result2 = $conn->query($sql2);



if ($result->num_rows > 0 && $result2->num_rows>0) 
{

   
    $row2 = $result2->fetch_assoc();
    $i=0;
    while ($row = $result->fetch_assoc()){
       

        $p_name = $row['p_name'];
        $p_email = $row['p_email'];
        $event_name = $row2['event_name'];
        $organizer = $row2['organizer'];

        $participants[]= array(
            'name'=>$row['p_name'],
            'email'=>$row['p_email'],
            'event_name'=>$row2['event_name'],
            'organizer'=>$row2['organizer']
        );
        
    }


}else{

}

// foreach($name as $name){
//     echo $name;
// }

$html ="
        
<!DOCTYPE html>
<html lang=\"en\">

<head>
    <meta charset=\"UTF-8\">
    <meta http-equiv=\"Content-Type\" content=\"text/html\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <title>Event Buddy || Proof of participation</title>
</head>

<body>

    <div style=\"text-align: center; border: 2px solid gray; width: fit-content; margin: auto; border-radius: 50px 0px 50px 0px; background-color: #ffefc3; padding: 50px;\">
        <div style=\"border-bottom: 2px solid blue; border-radius: 10px; padding: 20px;\">
            <img width=\"200px\" height=\"100px\"src=\"https://raw.githubusercontent.com/ilokeshghosh/RESOURCE_WAREHOUSE/main/Logos/eb-transperent-logo-16-9.png\"alt=\"event-buddy\">
        </div>
        <div>
            <div>
                <h1>Proof of Participation</h1>
                <h3>awarded to</h3>
                <h2>pname</h2>
                <p>for his successful participation in <b>eventName</b> organised by <b>Eorganizer</b></p>
            </div>
        </div>

        <div style=\"border-top: 2px solid blue; border-radius: 10px; padding: 20px;\">
            <p><b>Verify this Certificate </b><a href=\"#\">Here</a></p>
        </div>
    </div>
    
</body>

</html>


";

// echo sizeof($name);







try {
    //Server settings
    // $mail ->isSMTP();   
    $mail = new PHPMailer();           
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'eventbuddy05@gmail.com';  // ! admin.eventbuddy@gmail.com
    $mail->Password   = 'wobegropabtylszh';                               //SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
    // $mail->SMTPSecure = 'tls';            //Enable implicit TLS encryption
    $mail->Port       = 465;
    $mail->CharSet= 'UTF-8';
    $mail->ContentType ='text/html; charset=UTF-8';
    $mail->Encoding='8bit';
    
    // $mail->Port       = 587;
                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom('eventbuddy05@gmail.com', "admin@Event-Buddy");



   foreach($participants as $participants) { 
    $name = $participants['name'];
    $event_name = $participants['event_name'];
    $email = $participants['email'];
    $organizer = $participants['organizer'];
   
    $certificate_html = str_replace(
            array('pname', 'eventName','Eorganizer'),
            array($name, $event_name, $organizer), $html);

    $mail->addAddress($email, $name);
    $mail->IsHTML(true);
    $mail->Body   ="Here is your Certificate"; 
    // mb_convert_encoding($certificate_html, 'UTF-8');
    // $mail->Body = utf8_encode($body); 

   
    // echo $de;

    $mail->addStringAttachment($certificate_html, 'certificate.html', '8bit', 'text/html');
    // $mail->addStringAttachment($certificate_html, 'certificate.html', 'base64', 'text/html');

    // $mail->addCustomHeader('Content-Type: text/html');
    // $mail->addCustomHeader('Content-Disposition: attachment; filename="certificate.html"');
    $mail->Subject = 'Certificate of Participation';


    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
    
    if(!$mail->send()){
        echo "Mailer error".$mail->ErrorInfo;
    }else{

        ?>
        <script>
            alert("Certificate Sent");
            window.location.href = "../admin.php";
        </script>
        <?php
       
        "Mail sent to".$p_email;
    }

    $mail->clearAddresses();
    $mail->clearAttachments();
   


   

        
      //Add a recipient

    //Attachments
    // $path = "../QR/Generation/images/$qrimage";
    // $mail->addAttachment($path);         //Add attachments
    // $mail->AddEmbeddedImage($path, 'banana');

    //Content
    // $mail->isHTML(true);                                  //Set email format to HTML 
   


    
    

   





    

  

  

   
   


   }

         
        

        
        
    
    
    
    
    
    

}catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}





}
?>
